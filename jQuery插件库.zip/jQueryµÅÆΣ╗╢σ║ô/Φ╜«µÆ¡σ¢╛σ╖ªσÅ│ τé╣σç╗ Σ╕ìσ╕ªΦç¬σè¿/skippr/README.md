skippr
======

A super simple slideshow plugin for jQuery.

======

Visit http://iamapioneer.com/plugins/skippr/ for instructions
