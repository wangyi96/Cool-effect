<?php
// 登录界面
$userName = $_GET["loginName"];
$passWord = $_GET["loginWord"];

function login($userName,$passWord){
  $mysql = new mysqli('localhost','root','','h5class1');
  $mysql->query("set names utf8");

  $sql = "SELECT * FROM username WHERE userName='{$userName}'and passWord='{$passWord}'";

  $result= $mysql->query($sql);
  if ($result->num_rows) {
    echo 1;
    //  echo "<script>window.location.href='http://localhost/%E8%90%8C%E5%AE%A0%E9%A1%B9%E7%9B%AE/shop.html'</script>";
  }else {
     echo 0;
  }
  //断开与数据库的连接
  $mysql->close();
}


login($userName,$passWord);

?>
