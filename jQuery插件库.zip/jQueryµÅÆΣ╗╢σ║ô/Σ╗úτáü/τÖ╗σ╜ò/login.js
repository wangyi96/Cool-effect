//获取class函数
function byClass($) {
    return document.getElementsByClassName($) ? document.getElementsByClassName($) : -1;
}
//选测器函数 单个
function byQst($) {
    return document.querySelector($) ? document.querySelector($) : -1;
}
//选择器函数 多个
function byQstAll($) {
    return document.querySelectorAll($) ? document.querySelectorAll($) : -1;
}
var input = byQstAll(".input_wrap input"); //输入框
var btn = byQst(".btn_wrap button"); //登录按钮
var show_color = byClass("show_color")[0]; //显示框背景颜色
var img_small = byClass("img_small")[0]; //小图标
var showWrite = byQst(".show span"); //要显示的文字
var safeInput = byQst(".safe_wrap span input"); //是否选择自动登录
//验证登录
function checkLogin() {
    var userName = input[0].value;
    var passWord = input[1].value;
    if (window.ActiveXObject) {
        var XMLHttp = new ActiveXObject("Microsoft.XMLHTTP");
    } else {
        var XMLHttp = new XMLHttpRequest();
    }
    XMLHttp.open("GET", "login.php?loginName=" + userName + "&loginWord=" + passWord, true);
    XMLHttp.send(null);
    XMLHttp.onreadystatechange = function() {
        if (XMLHttp.readyState == 4) {
            if (XMLHttp.status == 200) {
                if (XMLHttp.response == 0) {
                    showSituation(3);
                } else {
                  if (isRecord) {
                     storageLogin();
                  }
                  storageUser();
                  window.open("shop.html","_self");
                }
            }
        }
    }
}
btn.onclick = function() {
        inputValue();
    }
    //处理输入框为0
function inputValue() {
    if (input[0].value.length == 0 && input[1].value.length == 0) {
        showSituation(0);
        input[0].focus();
    } else if (input[0].value.length == 0) {
        showSituation(1);
        input[0].focus();
    } else if (input[1].value.length == 0) {
        showSituation(2);
        input[1].focus();
    } else {
        checkLogin();
    }
}
//处理各种显示的情况
function showSituation(count) {
    img_small.style.height = '16px';
    img_small.style.background = 'url(resource/register_img/2.png) no-repeat';
    img_small.style.backgroundSize = '100% 100%';
    show_color.style.border = "1px solid rgb(250, 204, 198)";
    show_color.style.backgroundColor = "rgb(255, 235, 235)";
    show_color.style.color = "red";
    showArticle(count);
}
//处理显示的各种文字
var count;

function showArticle(count) {
    switch (count) {
        case 0:
            showWrite.innerText = '请输入用户名和密码';
            break;
        case 1:
            showWrite.innerText = '请输入用户名';
            break;
        case 2:
            showWrite.innerText = '请输入密码';
            break;
        case 3:
            showWrite.innerText = '用户名户名与密码不匹配，请重新输入';
            break;
    }
}
//自动登录的处理
safeInput.onclick = function() {
        if (safeInput.checked == true) {
            isRecord = true;
        } else if (safeInput.checked == false) {
            isRecord = false;
        }
    }
    //纪录用户名密码的函数
    var isRecord = false;
function storageLogin() {
    if (!window.localStorage) {

    } else {
        var storage = window.localStorage;
        var userName = input[0].value;
        var passWord = input[1].value;
        storage.setItem("userName", userName);
        storage.setItem("passWord", passWord);
        //获取当前时间
        var storageTime = new Date();
        var time = storageTime.getTime();
        storage.setItem("time", time);
    }

}
window.ready = readStorage();
//读取storage的数据
function readStorage(){
  var storage = window.localStorage;
  if (typeof(storage["userName"])=='undefined' || typeof(storage["passWord"])=='undefined') {
    return false;
  }else {
    var myDate =  new Date();
    var currenTime = myDate.getTime();
    if (currenTime >= Number(storage["time"])+86400000) {
      storage.clear();
    }else {
      input[0].value = storage["userName"];
      input[1].value =storage["passWord"];
    }

  }
}
//为各大主页购物车提供用户名
function storageUser() {
    if (!window.localStorage) {

    } else {
        var storage = window.localStorage;
        var user = input[0].value;
        storage.setItem("user", user);
        //获取当前时间
        var storageTime = new Date();
        var time = storageTime.getTime();
        storage.setItem("userTime", time);
    }

}
