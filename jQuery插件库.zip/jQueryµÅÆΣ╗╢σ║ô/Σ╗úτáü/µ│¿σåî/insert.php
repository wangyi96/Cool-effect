<?php
 $userName = $_POST["userName"];
 $passWord = $_POST["passWord"];
 $email = $_POST["email"];
 $phone = $_POST["phone"];
function addUser($userName,$passWord,$email,$phone){
  $mysql = new mysqli('localhost','root','','h5class1');
  $mysql->query("set names utf8");

  $sql = "INSERT INTO username(userName,passWord,email,phone) VALUES('{$userName}','{$passWord}','{$email}','{$phone}')";

  $result= $mysql->query($sql);
  if($result){
    header("Location:login.html");
  }else{
    echo false;
  }
  //断开与数据库的连接
  $mysql->close();
}
if (isset($userName)&&!empty($userName)) {
  addUser($userName,$passWord,$email,$phone);
}
?>
