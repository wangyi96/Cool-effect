//获取id函数
function byId($) {
    return document.getElementById($) ? document.getElementById($) : -1;
}
//获取class函数
function byClass($) {
    return document.getElementsByClassName($) ? document.getElementsByClassName($) : -1;
}
//选测器函数 单个
function byQst($) {
    return document.querySelector($) ? document.querySelector($) : -1;
}
//选择器函数 多个
function bYQstAll($) {
    return document.querySelectorAll($) ? document.querySelectorAll($) : -1;
}
//  加index属性
var inputOnfocus = bYQstAll(".input_wrap input"); //各个输入框
for (var i = 0; i < inputOnfocus.length; i++) {
    inputOnfocus[i].index = i;
}
var count;
for (var i = 0; i < inputOnfocus.length; i++) {
    inputOnfocus[i].onfocus = function() {
        this.placeholder = "";
        count = this.index;
        showMessage();
    }
}
//聚焦的时候
var show_img = byClass("show_img"); //文字前面的图标如'!';
var showScript = byClass("showScript"); //图标后面的文字 如“支持中文、字母、数字、"_" 的组合,4-20个字符”
var show = byClass("show");

function showMessage() {
    if (count <= 4) {
        ture_img[count].style.display = "none";
    }
    show_img[count].style.display = "inline";
    showScript[count].style.display = "inline";
    show_img[count].style.background = 'url(resource/register_img/1.png) no-repeat';
    show_img[count].style.width = '16px';
    show_img[count].style.height = "16px";
    show_img[count].style.backgroundSize = '100% 100%';
    show_img[count].style.float = "left";
    show_img[count].style.verticalAlign = "top";
    show_img[count].style.marginTop = '1px';
    showWriting(0);
    showScript[count].style.marginLeft = '5px';
    showScript[count].style.color = "#c5c5c5";
    //聚焦输入框是判断是否验证全为false
    if (count == 0) {
        isUserName = false;
    } else if (count == 1) {
        isPassWord = false;
    } else if (count == 2) {
        isConfirmPassword = false;
    } else if (count == 3) {
        isEmail = false;
    } else if (count == 4) {
        isPhone = false;
    } else if (count == 5) {
        isSecurityCode = false;
    }






}
//焦点聚集各个显示框时所显示的文字函数
function showWriting(choose) {
    switch (count) {
        case 0:
            if (choose == 0) {
                showScript[count].innerText = '支持中文、字母、数字、"_" 的组合,3-18个字符';
            } else if (choose == 1) {
                showScript[count].innerText = '字符长度只能在3-18之间或格式错误';
            } else if (choose == 2) {
                showScript[count].innerText = '请输入用户名';
            }

            break;
        case 1:
            if (choose == 0) {
                showScript[count].innerText = '建议使用字母、数字和下划线两种及以上组合,6-20个字符';
            } else if (choose == 1) {
                showScript[count].innerText = '长度只能在6-20字符之间';
            } else if (choose == 2) {
                showScript[count].innerText = '请输入密码';
            }

            break;
        case 2:
            if (choose == 0) {
                showScript[count].innerText = '请再次输入密码';
            } else if (choose == 1) {
                showScript[count].innerText = '两次输入密码不一致';
            } else if (choose == 2) {
                showScript[count].innerText = '请再次输入密码';
            }

            break;
        case 3:
            if (choose == 0) {
                showScript[count].innerText = '可以使用该邮箱找回密码';
            } else if (choose == 1) {
                showScript[count].innerText = '您输入的邮箱格式不正确';
            } else if (choose == 2) {
                showScript[count].innerText = '请输入邮箱';
            }

            break;
        case 4:
            if (choose == 0) {
                showScript[count].innerText = '可以使用该手机找回密码';
            } else if (choose == 1) {
                showScript[count].innerText = '您输入的手机号不正确';
            } else if (choose == 2) {
                showScript[count].innerText = '请输入手机号';
            }

            break;
        case 5:
            if (choose == 0) {
                showScript[count].innerText = '看不清？点击图片更换验证码';
            } else if (choose == 1) {
                showScript[count].innerText = '验证码错误,请重新输入';
            } else if (choose == 2) {
                showScript[count].innerText = '请输入验证码';
            }

            break;
    }
}
//格式不正确时显示的文字
function showWrong() {
    show_img[count].style.background = 'url(resource/register_img/2.png) no-repeat';
    show_img[count].style.width = '16px';
    show_img[count].style.height = "16px";
    show_img[count].style.backgroundSize = '100% 100%';
    show_img[count].style.borderRadius = "8px";
    show_img[count].style.float = "left";
    show_img[count].style.verticalAlign = "top";
    show_img[count].style.marginTop = '1px';
    showWriting(1);
    showScript[count].style.marginLeft = '5px';
    showScript[count].style.color = "red";
}
var ture_img = byClass("ture_img");
//  移除焦距时 验证用户名信息函数
function BlurName() {
    var userValue = inputOnfocus[0].value;
    var regExp = /^[0-9a-zA-Z\u4e00-\u9fa5_]{3,18}$/g;
    if (userValue == null || userValue == "") {
        inputOnfocus[0].placeholder = "您的用户名和登录名";
        show_img[0].style.display = "none";
        showScript[0].style.display = "none";
    } else if (regExp.test(userValue)) {
        userNameRegister(userValue);
    } else {
        showWrong();
    }
}
//用户已经注册时所处理的函数
function userNameTrue() {
    show_img[0].style.background = 'url(resource/register_img/6.png) no-repeat';
    show_img[0].style.width = '16px';
    show_img[0].style.height = "16px";
    show_img[0].style.backgroundSize = '100% 100%';
    show_img[0].style.borderRadius = "8px";
    show_img[0].style.float = "left";
    show_img[0].style.verticalAlign = "top";
    show_img[0].style.marginTop = '1px';
    showScript[0].innerText = '该用户已经注册';
    showScript[0].style.marginLeft = '5px';
    showScript[0].style.color = "red";
}
//关于用户名已经注册问题进行验证
function userNameRegister(userValue) {
    if (window.ActiveXObject) {
        var XMLHttp = new ActiveXObject("Microsoft.XMLHTTP");
    } else {
        var XMLHttp = new XMLHttpRequest();
    }
    XMLHttp.open("GET", "userName.php?username=" + userValue, true);
    XMLHttp.send(null);
    XMLHttp.onreadystatechange = function() {
        if (XMLHttp.readyState == 4) {
            if (XMLHttp.status == 200) {
                if (XMLHttp.response) {
                    userNameTrue();
                } else {
                    isUserName = true;
                    show_img[0].style.display = "none";
                    showScript[0].style.display = "none";
                    ture_img[0].style.display = "inline";
                }
            }
        }
    }
}

//移除焦距时  验证密码信息函数
function BlurPassword() {
    var passwordValue = inputOnfocus[1].value;
    var low = /^([0-9]{6,16}|[a-z]{6,16}|[A-Z]{6,16})$/g;
    var middle = /^[a-zA-Z0-9]{6,16}$/g;
    var high = /^[a-zA-Z0-9_]{6,16}$/g;
    if (passwordValue == null || passwordValue == "") {
        inputOnfocus[1].placeholder = "请您输入密码";
        show_img[1].style.display = "none";
        showScript[1].style.display = "none";
        inputOnfocus[2].focus();
    } else if (low.test(passwordValue)) {
        passwordIntensity(3);
        isPassWord = true;
        inputOnfocus[2].focus();
        ture_img[1].style.display = "inline";
    } else if (middle.test(passwordValue)) {
        passwordIntensity(4);
        isPassWord = true;
        inputOnfocus[2].focus();
        ture_img[1].style.display = "inline";
    } else if (high.test(passwordValue)) {
        passwordIntensity(5);
        isPassWord = true;
        inputOnfocus[2].focus();
        ture_img[1].style.display = "inline";
    } else {
        showWrong();
    }
}
//密码强度显示的文字函数
function passwordIntensity(countImg) {
    show_img[count].style.background = 'url(resource/register_img/' + countImg + '.png) no-repeat';
    show_img[count].style.width = '16px';
    show_img[count].style.height = "16px";
    show_img[count].style.backgroundSize = '100% 100%';
    show_img[count].style.borderRadius = "8px";
    show_img[count].style.float = "left";
    show_img[count].style.verticalAlign = "top";
    show_img[count].style.marginTop = '1px';
    if (countImg == 3) {
        showScript[count].innerText = '有被盗风险,建议使用字母、数字和下划线两种及以上组合';
    } else if (countImg == 4) {
        showScript[count].innerText = '安全强度适中，可以使用三种的组合来提高安全强度';
    } else if (countImg == 5) {
        showScript[count].innerText = '你的密码很安全';
    }
    showScript[count].style.marginLeft = '5px';
    showScript[count].style.color = "#c5c5c5";
}
//移除焦距时 验证确认密码信息函数
function BlurConfirmPassword() {
    var passwordValue = inputOnfocus[1].value;
    var confirmPasswordValue = inputOnfocus[2].value;
    if (confirmPasswordValue == null || confirmPasswordValue == "") {
        inputOnfocus[2].placeholder = "请您再次输入密码";
        show_img[2].style.display = "none";
        showScript[2].style.display = "none";
    } else if (passwordValue == confirmPasswordValue) {
        show_img[2].style.display = "none";
        showScript[2].style.display = "none";
        ture_img[2].style.display = "inline";
        isConfirmPassword = true;
    } else {
        showWrong();
    }
}
//移除焦距时 验证邮箱信息函数
function BlurEmail() {
    var emailValue = inputOnfocus[3].value;
    var regExp = /^[a-zA-Z0-9_]+@[a-z0-9]+(\.[a-z]{1,3})$/g;
    if (emailValue == null || emailValue == "") {
        inputOnfocus[3].placeholder = "请您输入邮箱账号";
        show_img[3].style.display = "none";
        showScript[3].style.display = "none";
    } else if (regExp.test(emailValue)) {
        show_img[3].style.display = "none";
        showScript[3].style.display = "none";
        ture_img[3].style.display = "inline";
        isEmail = true;
    } else {
        showWrong();
    }
}
//移除焦距时 验证手机号信息函数
function BlurPhone() {
    var phoneValue = inputOnfocus[4].value;
    var regExp = /^1[34578]\d{9}$/g;
    if (phoneValue == null || phoneValue == "") {
        inputOnfocus[4].placeholder = "建议使用常用手机";
        show_img[4].style.display = "none";
        showScript[4].style.display = "none";
    } else if (regExp.test(phoneValue)) {
        show_img[4].style.display = "none";
        showScript[4].style.display = "none";
        ture_img[4].style.display = "inline";
        isPhone = true;
    } else {
        showWrong();
    }
}
//当文档加载
//  window.ready =applyForCode();
//  function applyForCode(){
//    if (window.ActiveXObject) {
//        var XMLHttp = new ActiveXObject("Microsoft.XMLHTTP");
//    } else {
//        var XMLHttp = new XMLHttpRequest();
//    }
//    XMLHttp.open("GET", "captcha.php", true);
//    XMLHttp.send(null);
//    XMLHttp.onreadystatechange = function() {
//        if (XMLHttp.readyState == 4) {
//            if (XMLHttp.status == 200) {
//               console.log(XMLHttp.response);
//
//            }
//        }
//    }
// }
//移除焦距时 验证验证码信息
function BlurSecurityCode() {
    var codeValue = inputOnfocus[5].value;
    if (codeValue == null || codeValue == "") {
        inputOnfocus[5].placeholder = "请输入验证码";
        show_img[5].style.display = "none";
        showScript[5].style.display = "none";
    } else {
        if (window.ActiveXObject) {
            var XMLHttp = new ActiveXObject("Microsoft.XMLHTTP");
        } else {
            var XMLHttp = new XMLHttpRequest();
        }
        XMLHttp.open("GET", "verificationCode.php?captcha=" + codeValue, true);
        XMLHttp.send(null);
        XMLHttp.onreadystatechange = function() {
            if (XMLHttp.readyState == 4) {
                if (XMLHttp.status == 200) {
                    if (XMLHttp.response) {
                        SecurityCodeTrue();
                        isSecurityCode = true;
                    } else {
                        showWrong();
                    }
                }
            }
        }
    }

}
//验证码正确时处理的函数
function SecurityCodeTrue() {
    show_img[5].style.background = 'url(resource/register_img/code.png) no-repeat';
    show_img[5].style.width = '16px';
    show_img[5].style.height = "16px";
    show_img[5].style.backgroundSize = '100% 100%';
    show_img[5].style.borderRadius = "8px";
    show_img[5].style.float = "left";
    show_img[5].style.verticalAlign = "top";
    show_img[5].style.marginTop = '1px';
    showScript[5].innerText = '输入正确';
    showScript[5].style.marginLeft = '5px';
    showScript[5].style.color = "#c5c5c5";
}
//处理协议是否被同意
var agreeOn = byQst(".agreeOn_wrap input");
var showAgree = byClass("showAgree")[0];
var showOn = byClass("showOn")[0];
agreeOn.onclick = function() {
    if (agreeOn.checked == false) {
        showAgree.style.display = 'inline';
        showOn.style.display = "inline";
        isAgreeOn = false;
    } else if (agreeOn.checked == true) {
        showAgree.style.display = 'none';
        showOn.style.display = "none";
        isAgreeOn = true;
    }
}
var btn = byQst(".button_wrap input");
var isUserName = false; //判断用户名是否已经验证
var isPassWord = false; //判断密码是否已经验证
var isConfirmPassword = false; //判断验证密码是否已经验证
var isEmail = false; //判断邮箱是否已经验证
var isPhone = false; //判断手机号是否已经验证
var isSecurityCode = false; //判断验证码是否已经验证
var isAgreeOn = true; //判断协议是否已经勾选
var userWrap = byClass("user_wrap");
 function checkSubmit(){
        if (isUserName) {
            if (isPassWord) {
                if (isConfirmPassword) {
                    if (isEmail) {
                        if (isPhone) {
                            if (isSecurityCode) {
                                if (isAgreeOn) {
                                    return true;
                                }else {
                                  return false;
                                }

                            } else {
                                inputOnfocus[5].focus();
                                userWrap[5].style.border = "1px solid red";
                                showWrongBtn();
                                return false;
                            }
                        } else {
                            inputOnfocus[4].focus();
                            userWrap[4].style.border = "1px solid red";
                            showWrongBtn();
                            return false;
                        }
                    } else {
                        inputOnfocus[3].focus();
                        userWrap[3].style.border = "1px solid red";
                        showWrongBtn();
                        return false;
                    }
                } else {
                    inputOnfocus[2].focus();
                    userWrap[2].style.border = "1px solid red";
                    showWrongBtn();
                    return false;
                }
            } else {
                inputOnfocus[1].focus();
                userWrap[1].style.border = "1px solid red";
                showWrongBtn();
                return false;
            }
        } else {
            inputOnfocus[0].focus();
            userWrap[0].style.border = "1px solid red";
            showWrongBtn();
            return false;
        }

    }
    //处理没有填写输入框的文字
function showWrongBtn() {
    show_img[count].style.background = 'url(resource/register_img/2.png) no-repeat';
    show_img[count].style.width = '16px';
    show_img[count].style.height = "16px";
    show_img[count].style.backgroundSize = '100% 100%';
    show_img[count].style.borderRadius = "8px";
    show_img[count].style.float = "left";
    show_img[count].style.verticalAlign = "top";
    show_img[count].style.marginTop = '1px';
    showWriting(2);
    showScript[count].style.marginLeft = '5px';
    showScript[count].style.color = "red";
}
