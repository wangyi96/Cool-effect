 <?php
$mysql = new mysqli('localhost','root','','h5class1');
$username = $_GET["username"];
$mysql->query("set names utf8");
$sql =  "SELECT * FROM username WHERE userName='{$username}'";
//执行语句
$result = $mysql->query($sql);
//num_rows 查询返回的记录数
if($result->num_rows){
   echo true;
}else {
   echo false;
}


$mysql->close();


?>
